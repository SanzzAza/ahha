const GoodShortScraper = require('../src/scrapers/goodshortScraper');

describe('GoodShortScraper', () => {
  let scraper;

  beforeAll(() => {
    scraper = new GoodShortScraper();
  });

  test('should be initialized', () => {
    expect(scraper).toBeDefined();
    expect(scraper.baseUrl).toBe('https://www.goodshort.com/id');
  });

  test('should generate valid IDs', () => {
    const id = scraper.generateId('https://goodshort.com/drama-title/');
    expect(id).toMatch(/^[a-z0-9-]+$/);
    expect(id.length).toBeGreaterThan(0);
  });

  test('should extract rating correctly', () => {
    const cheerio = require('cheerio');
    const html = '<div class="rating">8.5</div>';
    const $ = cheerio.load(html);
    const rating = scraper.extractRating($('div'));
    expect(rating).toBe(8.5);
  });

  test('should handle empty search query', async () => {
    const results = await scraper.searchDramas('', 10);
    expect(results).toEqual([]);
  });

  test('should truncate long titles', () => {
    const drama = {
      title: 'a'.repeat(250)
    };
    expect(drama.title.length).toBeLessThanOrEqual(200);
  });
});
