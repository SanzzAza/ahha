const cacheManager = require('../src/cache/cacheManager');

describe('CacheManager', () => {
  afterEach(() => {
    cacheManager.clear();
  });

  test('should store and retrieve values', () => {
    cacheManager.set('test-key', { data: 'test' });
    const value = cacheManager.get('test-key');
    expect(value).toEqual({ data: 'test' });
  });

  test('should return null for missing keys', () => {
    const value = cacheManager.get('non-existent');
    expect(value).toBeNull();
  });

  test('should generate correct cache keys', () => {
    const key = cacheManager.generateKey('dramas', { page: 1, limit: 20 });
    expect(key).toBe('dramas:limit=20&page=1');
  });

  test('should provide stats', () => {
    const stats = cacheManager.getStats();
    expect(stats).toHaveProperty('enabled');
    expect(stats).toHaveProperty('ttl');
  });

  test('should clear all cache', () => {
    cacheManager.set('key1', 'value1');
    cacheManager.set('key2', 'value2');
    cacheManager.clear();
    expect(cacheManager.get('key1')).toBeNull();
    expect(cacheManager.get('key2')).toBeNull();
  });
});
