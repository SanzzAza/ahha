const express = require('express');
const router = express.Router();
const GoodShortScraper = require('../scrapers/goodshortScraper');
const cacheManager = require('../cache/cacheManager');
const logger = require('../utils/logger');

const scraper = new GoodShortScraper();

router.get('/', async (req, res, next) => {
  try {
    const limit = Math.min(req.query.limit || 20, 100);

    const cacheKey = cacheManager.generateKey('new_releases', { limit });
    let dramas = cacheManager.get(cacheKey);

    if (!dramas) {
      logger.info(`Fetching new releases - limit: ${limit}`);
      dramas = await scraper.getNewReleases(limit);
      cacheManager.set(cacheKey, dramas, 1800);
    }

    res.json({
      success: true,
      type: 'new_releases',
      data: dramas,
      total: dramas.length,
      cached: !!cacheManager.get(cacheKey)
    });
  } catch (error) {
    logger.error(`New releases route error: ${error.message}`);
    next({
      status: 500,
      message: error.message,
      details: 'Failed to fetch new releases'
    });
  }
});

module.exports = router;
