const express = require('express');
const router = express.Router();
const GoodShortScraper = require('../scrapers/goodshortScraper');
const cacheManager = require('../cache/cacheManager');
const logger = require('../utils/logger');

const scraper = new GoodShortScraper();

router.get('/', async (req, res, next) => {
  try {
    const { q } = req.query;
    const limit = Math.min(req.query.limit || 20, 100);

    if (!q || q.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Search query (q) is required'
      });
    }

    if (q.length > 100) {
      return res.status(400).json({
        success: false,
        error: 'Search query too long (max 100 characters)'
      });
    }

    const cacheKey = cacheManager.generateKey('search', { q, limit });
    let results = cacheManager.get(cacheKey);

    if (!results) {
      logger.info(`Searching: ${q}`);
      results = await scraper.searchDramas(q, limit);
      cacheManager.set(cacheKey, results, 3600);
    }

    res.json({
      success: true,
      query: q,
      data: results,
      total: results.length,
      cached: !!cacheManager.get(cacheKey)
    });
  } catch (error) {
    logger.error(`Search route error: ${error.message}`);
    next({
      status: 500,
      message: error.message,
      details: 'Search failed'
    });
  }
});

module.exports = router;
