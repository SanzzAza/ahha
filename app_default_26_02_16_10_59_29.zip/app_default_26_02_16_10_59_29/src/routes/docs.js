const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const docs = {
    success: true,
    name: 'GoodShort API Scraper',
    version: process.env.API_VERSION || 'v1',
    description: 'Production-ready API for scraping goodshort.com',
    baseUrl: `${req.protocol}://${req.get('host')}/api`,
    endpoints: [
      {
        path: '/health',
        method: 'GET',
        description: 'Health check endpoint',
        response: {
          status: 'healthy',
          uptime: 'number',
          cache: 'object'
        }
      },
      {
        path: '/dramas',
        method: 'GET',
        description: 'Get all dramas with pagination',
        queryParams: {
          page: 'number (default: 1)',
          limit: 'number (default: 20, max: 100)'
        },
        example: '/dramas?page=1&limit=20'
      },
      {
        path: '/dramas/:id',
        method: 'GET',
        description: 'Get single drama by ID',
        example: '/dramas/drama-slug'
      },
      {
        path: '/categories',
        method: 'GET',
        description: 'Get all available categories',
        example: '/categories'
      },
      {
        path: '/categories/:name',
        method: 'GET',
        description: 'Get dramas by category',
        queryParams: {
          page: 'number (default: 1)',
          limit: 'number (default: 20, max: 100)'
        },
        example: '/categories/romance?page=1&limit=20'
      },
      {
        path: '/trending',
        method: 'GET',
        description: 'Get trending dramas',
        queryParams: {
          limit: 'number (default: 20, max: 100)'
        },
        example: '/trending?limit=20'
      },
      {
        path: '/new',
        method: 'GET',
        description: 'Get new releases',
        queryParams: {
          limit: 'number (default: 20, max: 100)'
        },
        example: '/new?limit=20'
      },
      {
        path: '/search',
        method: 'GET',
        description: 'Search dramas by keyword',
        queryParams: {
          q: 'string (required, max: 100 chars)',
          limit: 'number (default: 20, max: 100)'
        },
        example: '/search?q=romance&limit=20'
      },
      {
        path: '/recommendations',
        method: 'GET',
        description: 'Get recommended dramas',
        queryParams: {
          limit: 'number (default: 20, max: 100)'
        },
        example: '/recommendations?limit=20'
      },
      {
        path: '/stats',
        method: 'GET',
        description: 'Get API statistics',
        example: '/stats'
      },
      {
        path: '/refresh',
        method: 'POST',
        description: 'Refresh/clear cache (requires API key)',
        authentication: 'X-API-KEY header or api_key query param',
        example: 'POST /refresh with header X-API-KEY: your-key'
      }
    ],
    responseFormat: {
      success: 'boolean',
      data: 'array or object',
      error: 'string (if error)',
      pagination: 'object (if applicable)',
      cached: 'boolean'
    },
    dramaObject: {
      id: 'string',
      title: 'string',
      url: 'string',
      image: 'string',
      description: 'string',
      rating: 'number',
      views: 'number',
      category: 'string',
      releaseDate: 'string (YYYY-MM-DD)',
      status: 'string (ongoing|completed)'
    },
    authentication: {
      type: 'API Key',
      header: 'X-API-KEY',
      queryParam: 'api_key',
      required: 'For refresh endpoint only'
    },
    rateLimit: {
      enabled: process.env.RATE_LIMIT_ENABLED !== 'false',
      window: `${parseInt(process.env.RATE_LIMIT_WINDOW || 900000) / 1000}s`,
      maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || 100)
    },
    cache: {
      enabled: process.env.CACHE_ENABLED !== 'false',
      ttl: `${parseInt(process.env.CACHE_TTL || 3600)}s`,
      maxSize: parseInt(process.env.CACHE_MAX_SIZE || 100)
    }
  };

  res.json(docs);
});

module.exports = router;
