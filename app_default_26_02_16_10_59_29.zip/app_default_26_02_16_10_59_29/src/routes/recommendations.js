const express = require('express');
const router = express.Router();
const GoodShortScraper = require('../scrapers/goodshortScraper');
const cacheManager = require('../cache/cacheManager');
const logger = require('../utils/logger');

const scraper = new GoodShortScraper();

router.get('/', async (req, res, next) => {
  try {
    const limit = Math.min(req.query.limit || 20, 100);

    const cacheKey = cacheManager.generateKey('recommendations', { limit });
    let dramas = cacheManager.get(cacheKey);

    if (!dramas) {
      logger.info(`Fetching recommendations - limit: ${limit}`);
      
      const trending = await scraper.getTrendingDramas(limit);
      const newReleases = await scraper.getNewReleases(Math.ceil(limit / 2));
      
      dramas = [
        ...trending.slice(0, Math.floor(limit * 0.7)),
        ...newReleases.slice(0, Math.ceil(limit * 0.3))
      ].slice(0, limit);

      cacheManager.set(cacheKey, dramas, 1800);
    }

    res.json({
      success: true,
      type: 'recommendations',
      data: dramas,
      total: dramas.length,
      cached: !!cacheManager.get(cacheKey)
    });
  } catch (error) {
    logger.error(`Recommendations route error: ${error.message}`);
    next({
      status: 500,
      message: error.message,
      details: 'Failed to fetch recommendations'
    });
  }
});

module.exports = router;
