const express = require('express');
const router = express.Router();
const GoodShortScraper = require('../scrapers/goodshortScraper');
const cacheManager = require('../cache/cacheManager');
const logger = require('../utils/logger');

const scraper = new GoodShortScraper();

router.get('/', async (req, res, next) => {
  try {
    const cacheKey = 'categories:all';
    let categories = cacheManager.get(cacheKey);

    if (!categories) {
      logger.info('Fetching all categories');
      categories = await scraper.getCategories();
      cacheManager.set(cacheKey, categories, 7200);
    }

    res.json({
      success: true,
      data: categories,
      total: categories.length,
      cached: !!cacheManager.get(cacheKey)
    });
  } catch (error) {
    logger.error(`Categories route error: ${error.message}`);
    next({
      status: 500,
      message: error.message,
      details: 'Failed to fetch categories'
    });
  }
});

router.get('/:name', async (req, res, next) => {
  try {
    const { name } = req.params;
    const page = req.query.page || 1;
    const limit = Math.min(req.query.limit || 20, 100);

    if (!name || name.length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Invalid category name'
      });
    }

    const cacheKey = cacheManager.generateKey('category_dramas', { name, page, limit });
    let dramas = cacheManager.get(cacheKey);

    if (!dramas) {
      logger.info(`Fetching dramas for category: ${name}`);
      dramas = await scraper.getDramasByCategory(name, page, limit);
      cacheManager.set(cacheKey, dramas);
    }

    res.json({
      success: true,
      category: name,
      data: dramas,
      pagination: {
        page: parseInt(page),
        limit: limit,
        total: dramas.length
      },
      cached: !!cacheManager.get(cacheKey)
    });
  } catch (error) {
    logger.error(`Category dramas route error: ${error.message}`);
    next({
      status: error.message.includes('not found') ? 404 : 500,
      message: error.message,
      details: 'Failed to fetch category dramas'
    });
  }
});

module.exports = router;
