const express = require('express');
const router = express.Router();
const cacheManager = require('../cache/cacheManager');
const logger = require('../utils/logger');

router.post('/', async (req, res, next) => {
  try {
    const action = req.query.action || 'all';

    logger.info(`Cache refresh requested - action: ${action}`);

    if (action === 'all') {
      cacheManager.clear();
      res.json({
        success: true,
        message: 'All cache cleared successfully',
        cleared: 'all'
      });
    } else {
      res.status(400).json({
        success: false,
        error: 'Invalid action',
        validActions: ['all']
      });
    }
  } catch (error) {
    logger.error(`Refresh route error: ${error.message}`);
    next({
      status: 500,
      message: error.message,
      details: 'Failed to refresh cache'
    });
  }
});

module.exports = router;
