const express = require('express');
const router = express.Router();
const cacheManager = require('../cache/cacheManager');

router.get('/', (req, res) => {
  res.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    cache: cacheManager.getStats(),
    version: process.env.API_VERSION || 'v1'
  });
});

module.exports = router;
