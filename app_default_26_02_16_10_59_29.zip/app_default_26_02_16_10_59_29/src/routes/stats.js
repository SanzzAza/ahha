const express = require('express');
const router = express.Router();
const cacheManager = require('../cache/cacheManager');

router.get('/', (req, res) => {
  res.json({
    success: true,
    stats: {
      cache: cacheManager.getStats(),
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      environment: process.env.NODE_ENV || 'development',
      apiVersion: process.env.API_VERSION || 'v1'
    }
  });
});

module.exports = router;
