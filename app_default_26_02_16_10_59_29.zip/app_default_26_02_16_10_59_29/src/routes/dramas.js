const express = require('express');
const router = express.Router();
const GoodShortScraper = require('../scrapers/goodshortScraper');
const cacheManager = require('../cache/cacheManager');
const logger = require('../utils/logger');

const scraper = new GoodShortScraper();

router.get('/', async (req, res, next) => {
  try {
    const page = req.query.page || 1;
    const limit = Math.min(req.query.limit || 20, 100);

    const cacheKey = cacheManager.generateKey('dramas', { page, limit });
    let dramas = cacheManager.get(cacheKey);

    if (!dramas) {
      logger.info(`Fetching dramas - page: ${page}, limit: ${limit}`);
      dramas = await scraper.getAllDramas(page, limit);
      cacheManager.set(cacheKey, dramas);
    }

    res.json({
      success: true,
      data: dramas,
      pagination: {
        page: parseInt(page),
        limit: limit,
        total: dramas.length,
        hasMore: dramas.length === limit
      },
      cached: !!cacheManager.get(cacheKey)
    });
  } catch (error) {
    logger.error(`Dramas route error: ${error.message}`);
    next({
      status: 500,
      message: error.message,
      details: 'Failed to fetch dramas'
    });
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!id || id.length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Invalid drama ID'
      });
    }

    const cacheKey = cacheManager.generateKey('drama', { id });
    let drama = cacheManager.get(cacheKey);

    if (!drama) {
      logger.info(`Fetching drama: ${id}`);
      drama = await scraper.getDramaSingle(id);
      cacheManager.set(cacheKey, drama);
    }

    res.json({
      success: true,
      data: drama,
      cached: !!cacheManager.get(cacheKey)
    });
  } catch (error) {
    logger.error(`Drama detail route error: ${error.message}`);
    next({
      status: error.message.includes('not found') ? 404 : 500,
      message: error.message,
      details: 'Failed to fetch drama details'
    });
  }
});

module.exports = router;
