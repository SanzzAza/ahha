const logger = require('./logger');

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const withRetry = async (fn, maxAttempts = 3, delayMs = 1000) => {
  let lastError;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      logger.warn(`Attempt ${attempt}/${maxAttempts} failed: ${error.message}`);

      if (attempt < maxAttempts) {
        const waitTime = delayMs * Math.pow(2, attempt - 1);
        logger.info(`Retrying after ${waitTime}ms...`);
        await delay(waitTime);
      }
    }
  }

  throw lastError;
};

const parseNumber = (value, defaultValue = 0) => {
  const parsed = parseInt(value);
  return isNaN(parsed) ? defaultValue : parsed;
};

const formatDate = (date) => {
  if (!(date instanceof Date)) {
    date = new Date(date);
  }
  return date.toISOString().split('T')[0];
};

const truncate = (str, maxLength = 100) => {
  if (typeof str !== 'string') return '';
  return str.length > maxLength ? str.substring(0, maxLength) + '...' : str;
};

const sanitizeUrl = (url) => {
  try {
    new URL(url);
    return url;
  } catch {
    return '';
  }
};

const generateHash = (str) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
};

module.exports = {
  delay,
  withRetry,
  parseNumber,
  formatDate,
  truncate,
  sanitizeUrl,
  generateHash
};
