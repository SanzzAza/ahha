const validator = {
  isValidId: (id) => {
    return typeof id === 'string' && id.length >= 2 && id.length <= 100;
  },

  isValidQuery: (query) => {
    return typeof query === 'string' && query.trim().length > 0 && query.length <= 200;
  },

  isValidPage: (page) => {
    const num = parseInt(page);
    return !isNaN(num) && num >= 1;
  },

  isValidLimit: (limit) => {
    const num = parseInt(limit);
    return !isNaN(num) && num >= 1 && num <= 100;
  },

  isValidUrl: (url) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  },

  isValidApiKey: (key) => {
    return typeof key === 'string' && key.length >= 10 && key.length <= 256;
  }
};

module.exports = validator;
