const axios = require('axios');
const cheerio = require('cheerio');
const logger = require('../utils/logger');
const { delay, withRetry } = require('../utils/helpers');

const HEADERS = {
  'User-Agent': process.env.USER_AGENT || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
  'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8',
  'Accept-Encoding': 'gzip, deflate, br',
  'Connection': 'keep-alive',
  'Upgrade-Insecure-Requests': '1'
};

class GoodShortScraper {
  constructor() {
    this.baseUrl = process.env.GOODSHORT_URL || 'https://www.goodshort.com/id';
    this.timeout = parseInt(process.env.GOODSHORT_TIMEOUT || 10000);
  }

  async fetchPage(url) {
    try {
      logger.info(`Fetching: ${url}`);
      const response = await axios.get(url, {
        headers: HEADERS,
        timeout: this.timeout,
        maxRedirects: 5,
        validateStatus: (status) => status < 500
      });

      if (response.status === 404) {
        throw new Error(`Page not found: ${url}`);
      }

      return response.data;
    } catch (error) {
      logger.error(`Fetch error: ${error.message}`);
      throw error;
    }
  }

  parseHTML(html) {
    return cheerio.load(html);
  }

  async getAllDramas(page = 1, limit = 20) {
    return withRetry(async () => {
      const url = `${this.baseUrl}/page/${page}/`;
      const html = await this.fetchPage(url);
      const $ = this.parseHTML(html);

      const dramas = [];

      const selectors = [
        '[data-post-id]',
        'article.post-item',
        '.drama-item',
        '.post-box'
      ];

      let $items = null;
      for (const selector of selectors) {
        $items = $(selector);
        if ($items.length > 0) {
          logger.info(`Using selector: ${selector} - Found ${$items.length} items`);
          break;
        }
      }

      if (!$items || $items.length === 0) {
        logger.warn('No drama items found, trying alternative parsing');
        return this.parseAlternativeDramas($, dramas, limit);
      }

      $items.slice(0, limit).each((index, element) => {
        try {
          const drama = this.extractDramaData($, element);
          if (drama && drama.id) {
            dramas.push(drama);
          }
        } catch (e) {
          logger.warn(`Error extracting drama at index ${index}: ${e.message}`);
        }
      });

      return dramas.slice(0, limit);
    });
  }

  parseAlternativeDramas($, dramas, limit) {
    const alternativeSelectors = [
      'div[class*="post"]',
      'div[class*="drama"]',
      'div[class*="item"]',
      'div.container > div > div'
    ];

    for (const selector of alternativeSelectors) {
      const $items = $(selector);
      if ($items.length > 5) {
        logger.info(`Alternative parsing using: ${selector}`);
        $items.slice(0, limit).each((i, el) => {
          const drama = this.extractDramaDataAlternative($, el);
          if (drama && drama.id) {
            dramas.push(drama);
          }
        });
        break;
      }
    }

    return dramas.slice(0, limit);
  }

  extractDramaData($, element) {
    const $el = $(element);

    const titleSelectors = ['h2', 'h3', 'a.post-title', '[class*="title"]', 'a'];
    let title = '';
    for (const selector of titleSelectors) {
      title = $el.find(selector).first().text().trim();
      if (title) break;
    }

    const linkSelectors = ['a[href*="/id/"]', 'a.post-link', 'a[href*=".com"]', 'a'];
    let url = '';
    for (const selector of linkSelectors) {
      url = $el.find(selector).first().attr('href');
      if (url && url.includes('goodshort')) {
        url = url.includes('http') ? url : this.baseUrl + url;
        break;
      }
    }

    const imageSelectors = ['img', 'img[class*="featured"]', 'img[class*="poster"]'];
    let image = '';
    for (const selector of imageSelectors) {
      image = $el.find(selector).first().attr('src') || $el.find(selector).first().attr('data-src');
      if (image) break;
    }

    const descriptionSelectors = ['p', '[class*="excerpt"]', '[class*="description"]'];
    let description = '';
    for (const selector of descriptionSelectors) {
      description = $el.find(selector).first().text().trim();
      if (description) break;
    }

    if (!title || !url) {
      return null;
    }

    const id = this.generateId(url);

    return {
      id,
      title: title.substring(0, 200),
      url: url.substring(0, 500),
      image: image ? image.substring(0, 500) : '',
      description: description ? description.substring(0, 500) : '',
      rating: this.extractRating($el),
      views: this.extractViews($el),
      category: this.extractCategory($el),
      releaseDate: this.extractReleaseDate($el),
      status: this.extractStatus($el)
    };
  }

  extractDramaDataAlternative($, element) {
    const $el = $(element);
    const $link = $el.find('a').first();
    const title = $link.text().trim() || $el.text().trim().split('\n')[0];
    let url = $link.attr('href') || '';

    if (!url.includes('http')) {
      url = this.baseUrl + url;
    }

    if (!title || !url.includes('goodshort')) {
      return null;
    }

    return {
      id: this.generateId(url),
      title: title.substring(0, 200),
      url: url.substring(0, 500),
      image: $el.find('img').first().attr('src') || '',
      description: '',
      rating: 0,
      views: 0,
      category: 'general',
      releaseDate: new Date().toISOString().split('T')[0],
      status: 'ongoing'
    };
  }

  extractRating($el) {
    const ratingText = $el.find('[class*="rating"]').text() || $el.find('[class*="star"]').text() || '';
    const match = ratingText.match(/(\d+\.?\d*)/);
    return match ? parseFloat(match[1]) : 0;
  }

  extractViews($el) {
    const viewsText = $el.find('[class*="views"]').text() || $el.text() || '';
    const match = viewsText.match(/(\d+)\s*K|\b(\d+)\b/);
    if (match) {
      return match[1] ? parseInt(match[1]) * 1000 : parseInt(match[2]);
    }
    return 0;
  }

  extractCategory($el) {
    const categoryText = $el.find('[class*="category"]').text() || $el.find('[class*="genre"]').text() || '';
    return categoryText.trim().substring(0, 50) || 'general';
  }

  extractReleaseDate($el) {
    const dateText = $el.find('[class*="date"]').text() || $el.find('time').text() || '';
    if (dateText) {
      try {
        const date = new Date(dateText);
        if (!isNaN(date)) {
          return date.toISOString().split('T')[0];
        }
      } catch (e) {
        logger.warn(`Date parsing error: ${e.message}`);
      }
    }
    return new Date().toISOString().split('T')[0];
  }

  extractStatus($el) {
    const statusText = $el.text().toLowerCase();
    if (statusText.includes('ended') || statusText.includes('selesai')) {
      return 'completed';
    }
    if (statusText.includes('ongoing') || statusText.includes('berjalan')) {
      return 'ongoing';
    }
    return 'ongoing';
  }

  generateId(url) {
    const slug = url.split('/').filter(Boolean).pop() || '';
    return slug.replace(/[^a-z0-9-]/gi, '').substring(0, 50) || `drama-${Date.now()}`;
  }

  async getCategories() {
    return withRetry(async () => {
      const html = await this.fetchPage(this.baseUrl);
      const $ = this.parseHTML(html);

      const categories = [];
      const seen = new Set();

      const selectors = [
        'a[href*="/category/"]',
        '[class*="category"] a',
        '[class*="genre"] a',
        'nav a'
      ];

      for (const selector of selectors) {
        const $links = $(selector);
        if ($links.length > 0) {
          $links.each((i, el) => {
            const $link = $(el);
            const href = $link.attr('href');
            const text = $link.text().trim();

            if (href && text && href.includes('goodshort') && !seen.has(text)) {
              seen.add(text);
              categories.push({
                name: text,
                slug: href.split('/').filter(Boolean).pop() || text.toLowerCase(),
                url: href.includes('http') ? href : this.baseUrl + href
              });
            }
          });

          if (categories.length >= 10) break;
        }
      }

      return categories.slice(0, 20);
    });
  }

  async getDramasByCategory(categoryName, page = 1, limit = 20) {
    return withRetry(async () => {
      const categories = await this.getCategories();
      const category = categories.find(
        c => c.name.toLowerCase() === categoryName.toLowerCase() ||
             c.slug === categoryName.toLowerCase()
      );

      if (!category) {
        throw new Error(`Category not found: ${categoryName}`);
      }

      const url = `${category.url}page/${page}/`;
      const html = await this.fetchPage(url);
      const $ = this.parseHTML(html);

      const dramas = [];
      const selectors = [
        '[data-post-id]',
        'article.post-item',
        '.drama-item'
      ];

      let $items = null;
      for (const selector of selectors) {
        $items = $(selector);
        if ($items.length > 0) break;
      }

      if ($items && $items.length > 0) {
        $items.slice(0, limit).each((i, el) => {
          const drama = this.extractDramaData($, el);
          if (drama && drama.id) {
            dramas.push(drama);
          }
        });
      }

      return dramas.slice(0, limit);
    });
  }

  async getDramaSingle(id) {
    return withRetry(async () => {
      const url = `${this.baseUrl}/${id}/`;
      const html = await this.fetchPage(url);
      const $ = this.parseHTML(html);

      const titleSelectors = ['h1', 'h2', '[class*="title"]'];
      let title = '';
      for (const selector of titleSelectors) {
        title = $(selector).first().text().trim();
        if (title) break;
      }

      const descriptionSelectors = ['[class*="description"]', '[class*="synopsis"]', 'p'];
      let description = '';
      for (const selector of descriptionSelectors) {
        description = $(selector).first().text().trim();
        if (description && description.length > 20) break;
      }

      const imageSelectors = ['img[class*="featured"]', 'img[class*="poster"]', 'img'];
      let image = '';
      for (const selector of imageSelectors) {
        image = $(selector).first().attr('src');
        if (image) break;
      }

      if (!title) {
        throw new Error(`Drama not found: ${id}`);
      }

      return {
        id,
        title: title.substring(0, 200),
        url: url.substring(0, 500),
        image: image ? image.substring(0, 500) : '',
        description: description.substring(0, 1000),
        content: $('body').text().substring(0, 5000),
        rating: this.extractRating($('body')),
        views: this.extractViews($('body')),
        category: this.extractCategory($('body')),
        releaseDate: this.extractReleaseDate($('body')),
        status: this.extractStatus($('body'))
      };
    });
  }

  async searchDramas(query, limit = 20) {
    if (!query || query.trim().length === 0) {
      return [];
    }

    return withRetry(async () => {
      const searchUrl = `${this.baseUrl}/?s=${encodeURIComponent(query)}`;
      const html = await this.fetchPage(searchUrl);
      const $ = this.parseHTML(html);

      const dramas = [];
      const selectors = [
        '[data-post-id]',
        'article.post-item',
        '.drama-item'
      ];

      let $items = null;
      for (const selector of selectors) {
        $items = $(selector);
        if ($items.length > 0) break;
      }

      if ($items && $items.length > 0) {
        $items.slice(0, limit).each((i, el) => {
          const drama = this.extractDramaData($, el);
          if (drama && drama.id && drama.title.toLowerCase().includes(query.toLowerCase())) {
            dramas.push(drama);
          }
        });
      }

      return dramas.slice(0, limit);
    });
  }

  async getTrendingDramas(limit = 20) {
    return withRetry(async () => {
      const urls = [
        `${this.baseUrl}/trending/`,
        `${this.baseUrl}/popular/`,
        `${this.baseUrl}/`
      ];

      for (const url of urls) {
        try {
          const html = await this.fetchPage(url);
          const $ = this.parseHTML(html);

          const dramas = [];
          const selectors = [
            '[data-post-id]',
            'article.post-item',
            '.drama-item'
          ];

          let $items = null;
          for (const selector of selectors) {
            $items = $(selector);
            if ($items.length > 0) break;
          }

          if ($items && $items.length >= 3) {
            $items.slice(0, limit).each((i, el) => {
              const drama = this.extractDramaData($, el);
              if (drama && drama.id) {
                drama.rank = i + 1;
                dramas.push(drama);
              }
            });

            if (dramas.length > 0) {
              return dramas;
            }
          }
        } catch (e) {
          logger.warn(`Trending fetch failed for ${url}: ${e.message}`);
          continue;
        }
      }

      return [];
    });
  }

  async getNewReleases(limit = 20) {
    return withRetry(async () => {
      const urls = [
        `${this.baseUrl}/terbaru/`,
        `${this.baseUrl}/new/`,
        `${this.baseUrl}/`
      ];

      for (const url of urls) {
        try {
          const html = await this.fetchPage(url);
          const $ = this.parseHTML(html);

          const dramas = [];
          const selectors = [
            '[data-post-id]',
            'article.post-item',
            '.drama-item'
          ];

          let $items = null;
          for (const selector of selectors) {
            $items = $(selector);
            if ($items.length > 0) break;
          }

          if ($items && $items.length > 0) {
            $items.slice(0, limit).each((i, el) => {
              const drama = this.extractDramaData($, el);
              if (drama && drama.id) {
                drama.isNew = true;
                dramas.push(drama);
              }
            });

            if (dramas.length > 0) {
              return dramas;
            }
          }
        } catch (e) {
          logger.warn(`New releases fetch failed for ${url}: ${e.message}`);
          continue;
        }
      }

      return [];
    });
  }
}

module.exports = GoodShortScraper;
