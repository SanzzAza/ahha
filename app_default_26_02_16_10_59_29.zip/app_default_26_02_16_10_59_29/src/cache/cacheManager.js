const NodeCache = require('node-cache');
const logger = require('../utils/logger');

class CacheManager {
  constructor() {
    this.enabled = process.env.CACHE_ENABLED !== 'false';
    this.ttl = parseInt(process.env.CACHE_TTL || 3600);
    this.maxSize = parseInt(process.env.CACHE_MAX_SIZE || 100);
    this.cache = new NodeCache({ 
      stdTTL: this.ttl,
      checkperiod: 600,
      maxKeys: this.maxSize
    });

    if (this.enabled) {
      logger.info(`Cache enabled with TTL: ${this.ttl}s, Max Size: ${this.maxSize}`);
    }
  }

  get(key) {
    if (!this.enabled) return null;

    try {
      const value = this.cache.get(key);
      if (value) {
        logger.debug(`Cache hit: ${key}`);
        return value;
      }
      logger.debug(`Cache miss: ${key}`);
      return null;
    } catch (error) {
      logger.error(`Cache get error: ${error.message}`);
      return null;
    }
  }

  set(key, value, ttl = null) {
    if (!this.enabled) return;

    try {
      this.cache.set(key, value, ttl || this.ttl);
      logger.debug(`Cache set: ${key}`);
    } catch (error) {
      logger.error(`Cache set error: ${error.message}`);
    }
  }

  delete(key) {
    if (!this.enabled) return;

    try {
      this.cache.del(key);
      logger.debug(`Cache deleted: ${key}`);
    } catch (error) {
      logger.error(`Cache delete error: ${error.message}`);
    }
  }

  clear() {
    if (!this.enabled) return;

    try {
      this.cache.flushAll();
      logger.info('Cache cleared');
    } catch (error) {
      logger.error(`Cache clear error: ${error.message}`);
    }
  }

  getStats() {
    if (!this.enabled) {
      return { enabled: false };
    }

    return {
      enabled: true,
      keys: this.cache.keys().length,
      maxKeys: this.maxSize,
      ttl: this.ttl,
      stats: this.cache.getStats()
    };
  }

  generateKey(prefix, params = {}) {
    const paramStr = Object.keys(params)
      .sort()
      .map(key => `${key}=${params[key]}`)
      .join('&');
    
    return paramStr ? `${prefix}:${paramStr}` : prefix;
  }
}

module.exports = new CacheManager();
