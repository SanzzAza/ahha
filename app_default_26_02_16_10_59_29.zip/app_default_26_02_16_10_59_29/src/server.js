const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const errorHandler = require('./middleware/errorHandler');
const requestLogger = require('./middleware/requestLogger');
const requestValidator = require('./middleware/requestValidator');
const authMiddleware = require('./middleware/authMiddleware');

const healthRoute = require('./routes/health');
const dramasRoute = require('./routes/dramas');
const categoriesRoute = require('./routes/categories');
const trendingRoute = require('./routes/trending');
const newReleasesRoute = require('./routes/newReleases');
const searchRoute = require('./routes/search');
const recommendationsRoute = require('./routes/recommendations');
const refreshRoute = require('./routes/refresh');
const statsRoute = require('./routes/stats');
const docsRoute = require('./routes/docs');

const app = express();

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true,
  optionsSuccessStatus: 200
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Compression
app.use(compression());

// Request logging
app.use(requestLogger);

// Rate limiting
if (process.env.RATE_LIMIT_ENABLED !== 'false') {
  const limiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW || 900000),
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || 100),
    message: {
      success: false,
      error: 'Too many requests, please try again later',
      retryAfter: '15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false,
    skip: (req) => {
      return req.path === '/api/health';
    }
  });

  app.use('/api/', limiter);
}

// Request validation
app.use(requestValidator);

// Routes
app.use('/api/health', healthRoute);
app.use('/api/docs', docsRoute);
app.use('/api/dramas', dramasRoute);
app.use('/api/categories', categoriesRoute);
app.use('/api/trending', trendingRoute);
app.use('/api/new', newReleasesRoute);
app.use('/api/search', searchRoute);
app.use('/api/recommendations', recommendationsRoute);
app.use('/api/refresh', authMiddleware, refreshRoute);
app.use('/api/stats', statsRoute);

// Root endpoint
app.get('/api', (req, res) => {
  res.json({
    success: true,
    message: 'GoodShort API Scraper',
    version: process.env.API_VERSION || 'v1',
    endpoints: {
      health: '/api/health',
      dramas: '/api/dramas',
      categories: '/api/categories',
      trending: '/api/trending',
      new: '/api/new',
      search: '/api/search',
      recommendations: '/api/recommendations',
      stats: '/api/stats',
      docs: '/api/docs'
    },
    documentation: '/api/docs'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint not found',
    path: req.path,
    method: req.method
  });
});

// Error handler (harus di paling akhir)
app.use(errorHandler);

module.exports = app;
