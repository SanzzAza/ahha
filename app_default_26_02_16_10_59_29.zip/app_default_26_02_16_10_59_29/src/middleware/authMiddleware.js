const authMiddleware = (req, res, next) => {
  const apiKey = req.headers['x-api-key'] || req.query.api_key;
  const expectedKey = process.env.API_KEY;

  if (!apiKey) {
    return res.status(401).json({
      success: false,
      error: 'API Key is required',
      hint: 'Pass API Key via X-API-KEY header or api_key query parameter'
    });
  }

  if (apiKey !== expectedKey) {
    return res.status(403).json({
      success: false,
      error: 'Invalid API Key'
    });
  }

  next();
};

module.exports = authMiddleware;
