const validator = require('../utils/validator');

const requestValidator = (req, res, next) => {
  if (req.query.limit) {
    const limit = parseInt(req.query.limit);
    if (isNaN(limit) || limit < 1 || limit > 100) {
      req.query.limit = 20;
    } else {
      req.query.limit = limit;
    }
  }

  if (req.query.offset) {
    const offset = parseInt(req.query.offset);
    if (isNaN(offset) || offset < 0) {
      req.query.offset = 0;
    } else {
      req.query.offset = offset;
    }
  }

  if (req.query.page) {
    const page = parseInt(req.query.page);
    if (isNaN(page) || page < 1) {
      req.query.page = 1;
    } else {
      req.query.page = page;
    }
  }

  next();
};

module.exports = requestValidator;
