const app = require('../src/server');

module.exports = app;
