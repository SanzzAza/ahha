const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const dotenv = require('dotenv');

dotenv.config();

const app = require('./src/server');

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || 'localhost';

const server = app.listen(PORT, HOST, () => {
  console.log(`
  ╔═══════════════════════════════════════════════════╗
  ║     🎬 GoodShort API Scraper Running Successfully  ║
  ╠═══════════════════════════════════════════════════╣
  ║ Server: ${HOST}:${PORT}
  ║ Environment: ${process.env.NODE_ENV || 'development'}
  ║ API Documentation: http://${HOST}:${PORT}/api/docs
  ║ Health Check: http://${HOST}:${PORT}/api/health
  ╚═══════════════════════════════════════════════════╝
  `);
});

process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
  });
});

module.exports = server;
