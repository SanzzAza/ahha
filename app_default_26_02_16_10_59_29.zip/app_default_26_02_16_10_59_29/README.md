# 🎬 GoodShort API Scraper

Production-ready web scraper API for GoodShort (https://www.goodshort.com/id) with complete Vercel deployment support. Hit the API endpoints directly without writing any code!

## 📋 Features

✅ **Complete Web Scraping**
- Intelligent HTML parsing with Cheerio
- Fallback selectors for robust scraping
- Automatic retry with exponential backoff (3 attempts)
- Error handling at every step

✅ **10 API Endpoints**
- GET /api/dramas - All dramas (paginated)
- GET /api/dramas/:id - Single drama details
- GET /api/categories - All categories
- GET /api/categories/:name - Dramas by category
- GET /api/trending - Trending dramas
- GET /api/new - New releases
- GET /api/search - Search dramas by keyword
- GET /api/recommendations - Recommended dramas
- GET /api/stats - API statistics
- POST /api/refresh - Clear cache (admin only)

✅ **Advanced Features**
- In-memory caching with configurable TTL
- Rate limiting (100 req/15 min)
- Request logging and monitoring
- API key authentication
- Compression and performance optimization
- CORS support
- Error handling with detailed messages

✅ **Deployment Ready**
- Vercel serverless deployment
- Docker support
- Environment variable configuration
- Production-grade error handling
- Health check endpoint

## 🛠️ Prerequisites

- Node.js 18.x or higher
- npm 9.x or higher
- Git (for deployment)
- Vercel account (for production deployment)

## 🚀 Quick Start

### Local Development

1. **Clone or download the repository**
