const dotenv = require('dotenv');
dotenv.config();

const cacheManager = require('../src/cache/cacheManager');

const command = process.argv[2];

switch (command) {
  case 'clear':
    cacheManager.clear();
    console.log('✓ Cache cleared');
    break;

  case 'stats':
    console.log('Cache Stats:');
    console.table(cacheManager.getStats());
    break;

  case 'help':
  default:
    console.log(`
Cache Manager Commands:
  npm run scrape:cache clear   - Clear all cache
  npm run scrape:cache stats   - Show cache statistics
    `);
}
