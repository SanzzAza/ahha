const dotenv = require('dotenv');
dotenv.config();

const GoodShortScraper = require('../src/scrapers/goodshortScraper');
const logger = require('../src/utils/logger');

const scraper = new GoodShortScraper();

const runScrapingDemo = async () => {
  try {
    console.log('\n🎬 GoodShort Scraping Demo Started\n');

    logger.info('1. Fetching all dramas...');
    const dramas = await scraper.getAllDramas(1, 5);
    console.log('✓ Dramas fetched:', dramas.length);
    console.table(dramas.slice(0, 3));

    logger.info('2. Fetching categories...');
    const categories = await scraper.getCategories();
    console.log('✓ Categories fetched:', categories.length);
    console.table(categories.slice(0, 3));

    logger.info('3. Searching for dramas...');
    const searchResults = await scraper.searchDramas('romance', 5);
    console.log('✓ Search results:', searchResults.length);

    logger.info('4. Fetching trending dramas...');
    const trending = await scraper.getTrendingDramas(5);
    console.log('✓ Trending dramas:', trending.length);

    logger.info('5. Fetching new releases...');
    const newReleases = await scraper.getNewReleases(5);
    console.log('✓ New releases:', newReleases.length);

    console.log('\n✅ Scraping demo completed successfully!\n');
  } catch (error) {
    logger.error(`Demo error: ${error.message}`);
    process.exit(1);
  }
};

runScrapingDemo();
